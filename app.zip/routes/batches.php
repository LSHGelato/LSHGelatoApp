<?php
declare(strict_types=1);

$router->get('/batches/new', function() {
  require_login();
  global $pdo;

  $rv_id = (int)($_GET['rv_id'] ?? 0);
  if ($rv_id<=0) { http_response_code(400); exit('Bad recipe version id'); }

  $st = $pdo->prepare("SELECT rv.*, r.name AS recipe_name
                       FROM recipe_versions rv
                       JOIN recipes r ON r.id = rv.recipe_id
                       WHERE rv.id=?");
  $st->execute([$rv_id]); $v = $st->fetch();
  if (!$v) { http_response_code(404); exit('No such version'); }

  $target = isset($_GET['target']) ? (float)$_GET['target'] : (float)$v['default_yield_g'];
  $tok = csrf_token();

  $it = $pdo->prepare("
    SELECT
      ri.id AS ri_id, ri.choice_group AS cg, ri.qty AS recipe_qty, ri.unit_kind, ri.is_primary,
      i.id AS ingredient_id, i.name AS ingredient_name,
      COALESCE(w.wac_bwp,0) AS wac
    FROM recipe_items ri
    JOIN ingredients i     ON i.id = ri.ingredient_id
    LEFT JOIN v_current_wac w ON w.ingredient_id = i.id
    WHERE ri.recipe_version_id = ?
    ORDER BY (ri.choice_group=0) DESC, ri.choice_group, ri.sort_order, i.name
  ");
  $it->execute([$rv_id]);
  $rows = $it->fetchAll();

  $groups = [];
  foreach ($rows as $r) $groups[(int)$r['cg']][] = $r;

  $selectedByGroup = [];
  foreach ($groups as $cg => $items) {
    if ($cg === 0) continue;
    $sel = null;
    foreach ($items as $r) if ($r['is_primary']) { $sel = (int)$r['ri_id']; break; }
    if ($sel === null) { $sel = (int)$items[0]['ri_id']; }
    $selectedByGroup[$cg] = $sel;
  }

  $hdr = "<h1>New Batch — ".h($v['recipe_name'])." v".(int)$v['version_no']."</h1>
    <form method='post' action='".url_for("/batches/save")."' id='batchForm'>
      <input type='hidden' name='_csrf' value='".h($tok)."'>
      <input type='hidden' name='rv_id' value='".(int)$rv_id."'>

      <div class='row'>
        <div class='col'><label>Batch date/time
          <input type='datetime-local' name='batch_dt' value='".h(date('Y-m-d\TH:i'))."'>
        </label></div>
        <div class='col'><label>Target mix (g)
          <input type='number' step='0.001' name='target' value='".number_format($target,3,'.','')."'>
        </label></div>
        <div class='col'><label>Deduct inventory?
          <select name='deduct'><option value='1'>Yes</option><option value='0'>No</option></select>
        </label></div>
      </div>

      <div class='row'>
        <div class='col'><label>Bowl weight (g) <input name='bowl' type='number' step='0.001'></label></div>
        <div class='col'><label>Bowl+mix (g) <input name='bowlmix' type='number' step='0.001'></label></div>
        <div class='col small muted' id='netWeightHint'></div>
      </div>

      <h2>Ingredients checklist</h2>";

  $tbl = "<table id='chk'><tr>
            <th class='left'>Group</th>
            <th class='left'>Ingredient</th>
            <th>Recipe qty</th>
            <th>Measured</th>
            <th>Unit</th>
            <th>WAC</th>
            <th>Ext. cost</th>
            <th>Use</th>
          </tr>";

  foreach ($groups as $cg => $items) {
    $isAlt = ($cg !== 0);
    $rowspan = max(1, count($items));
    foreach ($items as $idx => $r) {
      $ri   = (int)$r['ri_id'];
      $ing  = (int)$r['ingredient_id'];
      $unit = h($r['unit_kind']);
      $wac  = (float)$r['wac'];
      $rq   = (float)$r['recipe_qty'];

      $measuredName = "measured[$ri]";
      $checkedName  = "used[$ri]";
      $ingHidden    = "<input type='hidden' name='ingredient_id[$ri]' value='$ing'>";

      $useCell = "";
      $groupCell = "";
      $disabled = "";

      if ($isAlt) {
        $sel = ($selectedByGroup[$cg] ?? $ri) === $ri;
        $disabled = $sel ? "" : "disabled";
        $useCell = "<label><input type='radio' name='alt[$cg]' value='$ri' ".($sel?'checked':'')." class='altpick' data-group='$cg' data-ri='$ri'> choose</label>";
        if ($idx === 0) $groupCell = "<td rowspan='$rowspan' class='center'><strong>".(int)$cg."</strong></td>";
      } else {
        $useCell = "<input type='checkbox' name='{$checkedName}' value='1' checked class='usechk' data-ri='$ri'>";
      }

      $tbl .= "<tr>"
           . ($groupCell ?: "<td class='center'>".($isAlt?'':'—')."</td>")
           . "<td class='left'>".h($r['ingredient_name'])."</td>"
           . "<td class='right'><span class='rq' data-ri='$ri'>".number_format($rq,3)."</span></td>"
           . "<td class='right'><input type='number' step='0.001' name='{$measuredName}' value='".number_format($rq,3,'.','')."' class='meas' data-ri='$ri' $disabled></td>"
           . "<td class='center'>$unit</td>"
           . "<td class='right'><span class='wac' data-ri='$ri'>".number_format($wac,4)."</span></td>"
           . "<td class='right'><span class='ext' data-ri='$ri'>".number_format($rq*$wac,4)."</span></td>"
           . "<td class='center'>$useCell $ingHidden</td>"
           . "</tr>";
    }
  }
  $tbl .= "<tr><td colspan='6' class='right'><strong>Total cost (BWP)</strong></td>
             <td class='right'><strong id='totalCost'>0.0000</strong></td>
             <td></td></tr>
           </table>

           <p class='small muted'>Ext. cost updates with measured qty × WAC. Alternates: choose exactly one per group. Uncheck a non-alternate to skip it.</p>

           <button>Save batch</button>
    </form>

    <script>
    (function(){
      function recalcOne(ri){
        var m = parseFloat((document.querySelector(\"input[name='measured[\"+ri+\"]']\")||{}).value||'0');
        var w = parseFloat((document.querySelector(\".wac[data-ri='\"+ri+\"']\")||{}).textContent||'0');
        var ext = m*w;
        var el = document.querySelector(\".ext[data-ri='\"+ri+\"']\");
        if (el) el.textContent = (isFinite(ext)?ext:0).toFixed(4);
      }
      function recalcTotal(){
        var total = 0;
        document.querySelectorAll('#chk .ext').forEach(function(e){
          var tr = e.closest('tr');
          var radio = tr.querySelector('input.altpick');
          if (radio){
            if (!radio.checked) return;
          } else {
            var chk = tr.querySelector('input.usechk');
            if (chk && !chk.checked) return;
          }
          var v = parseFloat(e.textContent||'0');
          if (!isNaN(v)) total += v;
        });
        var t = document.getElementById('totalCost');
        if (t) t.textContent = total.toFixed(4);
      }
      function refreshNet(){
        var bowl = parseFloat(document.querySelector(\"input[name='bowl']\").value||'0');
        var mix  = parseFloat(document.querySelector(\"input[name='bowlmix']\").value||'0');
        var net  = mix - bowl;
        var h = document.getElementById('netWeightHint');
        if (h) h.textContent = isFinite(net) ? ('Net mix ≈ '+net.toFixed(3)+' g') : '';
      }
      function applyAltState(group){
        document.querySelectorAll(\"input.altpick[data-group='\"+group+\"']\").forEach(function(r){
          var ri = r.getAttribute('data-ri');
          var inp = document.querySelector(\"input[name='measured[\"+ri+\"]']\");
          if (inp) inp.disabled = !r.checked;
        });
      }
      document.querySelectorAll('input.meas').forEach(function(inp){
        inp.addEventListener('input', function(){
          var ri = this.getAttribute('data-ri'); recalcOne(ri); recalcTotal();
        });
      });
      document.querySelectorAll('input.usechk').forEach(function(chk){
        chk.addEventListener('change', function(){
          var ri = this.getAttribute('data-ri');
          var inp = document.querySelector(\"input[name='measured[\"+ri+\"]']\");
          if (inp) inp.disabled = !this.checked;
          recalcTotal();
        });
      });
      document.querySelectorAll('input.altpick').forEach(function(r){
        applyAltState(r.getAttribute('data-group'));
        r.addEventListener('change', function(){
          applyAltState(this.getAttribute('data-group'));
          recalcTotal();
        });
      });
      ['bowl','bowlmix'].forEach(function(n){
        var el = document.querySelector(\"input[name='\"+n+\"']\");
        if (el) el.addEventListener('input', refreshNet);
      });
      document.querySelectorAll('span.ext').forEach(function(e){
        var ri = e.getAttribute('data-ri'); recalcOne(ri);
      });
      recalcTotal(); refreshNet();
    })();
    </script>";

  render('New Batch', $hdr.$tbl);
});

$router->post('/batches/save', function() {
  require_login(); post_only(); global $pdo;

  $rv_id = (int)($_POST['rv_id'] ?? 0);
  if ($rv_id <= 0) { http_response_code(400); render('Batch error','<p class="err">Bad recipe version id.</p>'); return; }

  // Fetch default_yield for scaling
  $rv = $pdo->prepare("SELECT default_yield_g FROM recipe_versions WHERE id=?");
  $rv->execute([$rv_id]); $rvRow = $rv->fetch();
  if (!$rvRow) { http_response_code(404); render('Batch error','<p class="err">Recipe version not found.</p>'); return; }
  $default_yield = (float)$rvRow['default_yield_g'];

  $batch_date = $_POST['batch_dt'] ?? date('Y-m-d H:i:s');
  $txn_date   = date('Y-m-d', strtotime($batch_date));
  $target     = (float)($_POST['target'] ?? 0);
  $bowl       = (float)($_POST['bowl'] ?? 0);
  $bowlmix    = (float)($_POST['bowlmix'] ?? 0);
  $actual     = $bowlmix - $bowl;
  $deduct     = (int)($_POST['deduct'] ?? 1) ? 1 : 0;

  $measured = array_map('floatval', $_POST['measured'] ?? []);
  $used     = $_POST['used'] ?? [];
  $altPick  = $_POST['alt']  ?? [];
  $uid      = (int)($_SESSION['user']['id'] ?? 0);

  try {
    $pdo->beginTransaction();

    // 1) Insert batch header
    $insB = $pdo->prepare("
      INSERT INTO batches
        (recipe_version_id, batch_date, target_mix_g, bowl_weight_g, bowl_plus_mix_g, actual_mix_g, deduct_inventory, created_by)
      VALUES (?,?,?,?,?,?,?,?)
    ");
    $insB->execute([$rv_id, $batch_date, $target, $bowl, $bowlmix, $actual, $deduct, $uid]);
    $batch_id = (int)$pdo->lastInsertId();

    // 2) Load recipe items
    $ritems = $pdo->prepare("
      SELECT id, ingredient_id, choice_group, unit_kind, qty AS recipe_qty
      FROM recipe_items
      WHERE recipe_version_id=?
      ORDER BY choice_group, sort_order, id
    ");
    $ritems->execute([$rv_id]);
    $riRows = $ritems->fetchAll();

    $scale = ($default_yield > 0) ? ($target / $default_yield) : 1.0;

    $byRi  = []; $groups = []; $ingIds = [];
    foreach ($riRows as $r) {
      $ri = (int)$r['id'];
      $byRi[$ri] = $r;
      $groups[(int)$r['choice_group']][] = $ri;
      $ingIds[(int)$r['ingredient_id']] = true;
    }

    // 3) Snapshot current WAC for all referenced ingredients
    $wac = [];
    if (!empty($ingIds)) {
      $place = implode(',', array_fill(0, count($ingIds), '?'));
      $stW = $pdo->prepare("SELECT ingredient_id, wac_bwp FROM v_current_wac WHERE ingredient_id IN ($place)");
      $stW->execute(array_keys($ingIds));
      foreach ($stW as $row) $wac[(int)$row['ingredient_id']] = (float)$row['wac_bwp'];
    }

    // 4) Determine which RI rows are used and aggregate actual usage by ingredient
    $usedRi = []; $totalsByIng = []; $rowsToInsert = [];
    foreach ($groups as $cg => $riList) {
      if ($cg === 0) {
        foreach ($riList as $ri) {
          $qty = isset($measured[$ri]) ? (float)$measured[$ri] : 0.0;
          if (!isset($used[$ri]) || $qty <= 0) continue;
          $usedRi[$ri] = true;
        }
      } else {
        $selRi = isset($altPick[$cg]) ? (int)$altPick[$cg] : 0;
        if ($selRi && in_array($selRi, $riList, true)) {
          $qty = isset($measured[$selRi]) ? (float)$measured[$selRi] : 0.0;
          if ($qty > 0) $usedRi[$selRi] = true;
        }
      }
    }

    foreach ($usedRi as $ri => $_) {
      $row = $byRi[$ri];
      $iid = (int)$row['ingredient_id'];
      $u   = $row['unit_kind'];
      $qty = (float)$measured[$ri];
      $scaled = (float)$row['recipe_qty'] * $scale;

      $rowsToInsert[] = [
        'ri'      => $ri,
        'iid'     => $iid,
        'scaled'  => $scaled,
        'unit'    => $u,
        'meas'    => $qty,
      ];
      $totalsByIng[$iid] = ($totalsByIng[$iid] ?? 0) + $qty;
    }

    // 5) Save resolutions (replace set)
    $pdo->prepare("DELETE FROM batch_ingredient_resolutions WHERE batch_id=?")->execute([$batch_id]);
    if (!empty($rowsToInsert)) {
      $insR = $pdo->prepare("
        INSERT INTO batch_ingredient_resolutions
          (batch_id, recipe_item_id, resolved_ingredient_id, scaled_qty, unit_kind,
           checked_flag, measured_qty, checked_at, checked_by)
        VALUES (?,?,?,?,?, 1, ?, NOW(), ?)
      ");
      foreach ($rowsToInsert as $r) {
        $insR->execute([$batch_id, $r['ri'], $r['iid'], $r['scaled'], $r['unit'], $r['meas'], $uid]);
      }
    }

    // 6) Idempotent inventory deductions (txn_type='consumption')
    if ($deduct && !empty($totalsByIng)) {
      $stmtIns = $pdo->prepare("
        INSERT INTO inventory_txns
          (ingredient_id, txn_ts, txn_date, txn_type, qty, unit_kind, unit_cost_bwp,
           source_table, source_id, note, created_by)
        VALUES (?, NOW(), ?, 'consumption', ?, (SELECT unit_kind FROM ingredients WHERE id=?), ?,
                'batches', ?, CONCAT('Batch ', ?), ?)
        ON DUPLICATE KEY UPDATE
          qty=VALUES(qty), unit_cost_bwp=VALUES(unit_cost_bwp), note=VALUES(note)
      ");

      foreach ($totalsByIng as $iid => $qty) {
        $iid = (int)$iid;
        $negQty = -1.0 * (float)$qty; // consumption is negative
        $w     = $wac[$iid] ?? 0.0;
        $stmtIns->execute([$iid, $txn_date, $negQty, $iid, $w, $batch_id, $batch_id, $uid]);
      }
    }

    // 7) Compute COGS from ledger rows for this batch
    $pdo->prepare("
      UPDATE batches b
      JOIN (
        SELECT source_id AS bid, SUM(ABS(qty)*unit_cost_bwp) AS total
        FROM inventory_txns
        WHERE source_table='batches' AND source_id=?
        GROUP BY source_id
      ) x ON x.bid=b.id
      SET b.cogs_bwp = x.total
      WHERE b.id=?
    ")->execute([$batch_id, $batch_id]);

    // Ensure non-null
    $pdo->prepare("UPDATE batches SET cogs_bwp = COALESCE(cogs_bwp, 0) WHERE id=?")->execute([$batch_id]);

    $pdo->commit();
    render('Batch saved', "<p class='ok'>Batch #".$batch_id." saved.</p><p><a href='".url_for("/recipes/items?rv_id=".$rv_id)."'>Back to recipe</a></p>");

  } catch (Throwable $e) {
    $pdo->rollBack();
    render('Batch error', "<p class='err'>".h($e->getMessage())."</p><p><a href='".url_for("/batches/new?rv_id=".$rv_id)."'>Back</a></p>");
  }
});
